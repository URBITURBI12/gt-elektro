# Monteranje domofonov

## Kako objaviti
1. Razširite ZIP datoteko.
2. Naložite mapo na Netlify ali drug hosting.
3. Glavna datoteka je `index.html`.
4. Za galerijo ustvarite mapo `images` in vanjo dodajte fotografije z imeni `delo1.jpg`, `delo2.jpg`, `delo3.jpg`.
5. Po objavi lahko povežete svojo domeno, npr. monteranje-domofonov.si.
6. Nato spletno mesto dodajte v Google Search Console.

## Podatki
Tomaž Gregorčič
041 552 175
Območje: Ljubljana, Domžale, Kamnik, Mengeš
